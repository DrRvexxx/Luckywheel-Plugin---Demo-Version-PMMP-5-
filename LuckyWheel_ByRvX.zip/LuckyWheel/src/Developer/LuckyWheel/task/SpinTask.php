<?php

declare(strict_types=1);

namespace Developer\LuckyWheel\task;

use pocketmine\scheduler\Task;
use pocketmine\player\Player;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\Server;
use pocketmine\world\sound\ClickSound;
use pocketmine\world\sound\XpLevelUpSound;

class SpinTask extends Task {

    private Player $player;
    private array $rewards;
    private int $ticks = 0;
    private array $wheelStates = ["|", "/", "-", "\\"];

    public function __construct(Player $player, array $rewards) {
        $this->player = $player;
        $this->rewards = $rewards;
    }

    public function onRun(): void {
        if (!$this->player->isOnline()) {
            $this->getHandler()?->cancel();
            return;
        }

        if ($this->ticks < 20) {
            $state = $this->wheelStates[$this->ticks % count($this->wheelStates)];
            $this->player->sendTitle("§eSpinning §6{$state}", "§7Please wait...");
            $this->player->getWorld()->addSound($this->player->getLocation(), new ClickSound());
            $this->ticks++;
        } else {
            $this->getHandler()?->cancel();
            $this->giveReward();
        }
    }

    private function giveReward(): void {
        $totalChance = 0;
        foreach ($this->rewards as $reward) {
            $totalChance += $reward["chance"];
        }

        $rand = mt_rand(1, $totalChance);
        $current = 0;
        $selectedReward = null;

        foreach ($this->rewards as $reward) {
            $current += $reward["chance"];
            if ($rand <= $current) {
                $selectedReward = $reward;
                break;
            }
        }

        if ($selectedReward !== null) {
            $this->player->sendTitle("§a§lWINNER!", "§e" . $selectedReward["name"]);
            $this->player->getWorld()->addSound($this->player->getLocation(), new XpLevelUpSound(30));
            
            $cmd = str_replace("{player}", '"' . $this->player->getName() . '"', $selectedReward["cmd"]);
            Server::getInstance()->getCommandMap()->dispatch(new ConsoleCommandSender(Server::getInstance(), Server::getInstance()->getLanguage()), $cmd);
        }
    }
}