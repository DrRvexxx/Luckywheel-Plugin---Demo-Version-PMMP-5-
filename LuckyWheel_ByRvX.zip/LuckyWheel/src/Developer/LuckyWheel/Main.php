<?php

declare(strict_types=1);

namespace Developer\LuckyWheel;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use Developer\LuckyWheel\form\SimpleForm;
use Developer\LuckyWheel\task\SpinTask;
use pocketmine\item\VanillaItems;

class Main extends PluginBase {

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->getLogger()->info("§bLuckyWheel Enabled - By Rvexxx Khanoom =D");
    }

    protected function onDisable(): void {
        $this->getLogger()->info("§cPlugin Disabled");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "luckywheel") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§cThis command can only be used in-game.");
                return true;
            }

            if (!$sender->hasPermission("luckywheel.use")) {
                $sender->sendMessage("§cYou do not have permission to use this command.");
                return true;
            }

            $this->openWheelForm($sender);
            return true;
        }
        return false;
    }

    private function openWheelForm(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data) {
            if ($data === null) {
                return;
            }

            if ($data === 0) {
                $this->processSpin($player);
            }
        });

        $costType = $this->getConfig()->getNested("cost.type", "xp");
        $costAmount = $this->getConfig()->getNested("cost.amount", 5);
        $costString = $costType === "xp" ? "{$costAmount} XP Levels" : "{$costAmount} Diamonds";

        $form->setTitle("§l§6LUCKY WHEEL");
        $form->setContent("§7Try your luck! Each spin costs §e{$costString}§7.\n\n§fAre you ready to spin the wheel?");
        $form->addButton("§l§aSPIN NOW\n§eClick to play");
        $form->addButton("§cExit");

        $player->sendForm($form);
    }

    private function processSpin(Player $player): void {
        $costType = $this->getConfig()->getNested("cost.type", "xp");
        $costAmount = $this->getConfig()->getNested("cost.amount", 5);

        if ($costType === "xp") {
            if ($player->getXpManager()->getXpLevel() < $costAmount) {
                $player->sendMessage("§cYou do not have enough XP levels! You need {$costAmount} levels.");
                return;
            }
            $player->getXpManager()->setXpLevel($player->getXpManager()->getXpLevel() - $costAmount);
        } else {
            $diamond = VanillaItems::DIAMOND()->setCount($costAmount);
            if (!$player->getInventory()->contains($diamond)) {
                $player->sendMessage("§cYou do not have enough diamonds! You need {$costAmount} diamonds.");
                return;
            }
            $player->getInventory()->removeItem($diamond);
        }

        $rewards = $this->getConfig()->get("rewards", []);
        if (empty($rewards)) {
            $player->sendMessage("§cThere are no rewards configured in the Lucky Wheel.");
            return;
        }

        $this->getScheduler()->scheduleRepeatingTask(new SpinTask($player, $rewards), 2);
    }
}